package com.example.matala22;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MyData {

    static String[] nameArray = {"Ash Ketchum", "Misty", "Brock", "Pikachu", "Squirtle", "Charmander", "Bulbasaur","Butterfree", "Jessie", "James", "Meowth"};
    static String[] versionArray = {"The protagonist", "Ash's friend", "Ash's friend", "electrical pokemon", "water pokemon", "fire pokemon", "grass pokemon", "flying pokemon", "A member of Team Rocket", "A member of Team Rocket","A member of Team Rocket"};

    static Integer[] drawableArray = {R.drawable.ash_ketchum, R.drawable.misty, R.drawable.brock,
            R.drawable.pikachu, R.drawable.squirtle, R.drawable.charmander, R.drawable.bulbasaur,
            R.drawable.butterfree, R.drawable.jessie, R.drawable.james,R.drawable.meowth};

    static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    static String[] HeroDeatails= {"Ash is the main character of the Pokémon anime. He is also the main character of various manga based on the anime ",
                                    "Misty is a Gym Leader of Cerulean City's Gym, known officially as the Cerulean Gym.",
                                    "Brock is Ash friends who walk next to him ", "Pikachu is the first Pokemon of Ash and most known pokemon",
                                    "Squirtle is one of the three pokemon avilable for young coach ",
            "Charmander is one of the three pokemon avilable for young coach" , "Bulbasaur is one of the three pokemon avilable for young coach",
                                     "Butterfree was the first pokemon Ash got", "Jessie is a the bad character from team rocket", "james is a the bad character from team rocket",
                                     "Meowt is a the bad character from team rocket"   };

    public static void  getPicture(View view, int id) {
        ImageView imageView= view.findViewById(R.id.imageView2);
        imageView.setImageResource(drawableArray[id]);
    }

    public static void  getMoreDetails(View view, int id) {
        TextView textView = view.findViewById(R.id.more_details_textView2);
        textView.setText(HeroDeatails[id]);
    }
}


