package com.example.matala22;

import static com.example.matala22.MyData.*;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FragmentHeroDeatails#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentHeroDeatails extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String HERO_NAME = "param1";
    private static final String HERO_DETAILS = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1_name;
    private String mParam2_details;

    public FragmentHeroDeatails() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FragmentHeroDeatails.
     */
    // TODO: Rename and change types and number of parameters
    public static FragmentHeroDeatails newInstance(String name, String deatails) {
        FragmentHeroDeatails fragment = new FragmentHeroDeatails();
        Bundle args = new Bundle();
        args.putString(HERO_NAME, name);
        args.putString(HERO_DETAILS, deatails);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1_name = getArguments().getString(HERO_NAME);
            mParam2_details = getArguments().getString(HERO_DETAILS);
        }
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_hero_deatails, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        FragmentHeroDeatailsArgs args= FragmentHeroDeatailsArgs.fromBundle(getArguments());
        DataModel hero = args.getMyDataModel();
        System.out.println("i did it "+ hero.getName()+" "+ hero.getVersion()+" "+hero.getImage()+" "+hero.getId());

        TextView UserName, details, description;
        ImageView imageView;
        Integer ID;
        UserName = (TextView) view.findViewById(R.id.name_textView2);
        details = (TextView) view.findViewById(R.id.description_textView2);
//        description = (TextView) view.findViewById(R.id.more_details_textView2);
//        imageView = (ImageView) view.findViewById(R.id.imageView2);

        UserName.setText(hero.getName());
        details.setText(hero.getVersion());
        ID= hero.getId();
        MyData.getPicture(view, ID);
        MyData.getMoreDetails(view, ID);




//        view.findViewById(R.id.description_textView2)= hero.getVersion();

    }

}