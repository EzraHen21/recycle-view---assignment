package com.example.matala22;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    private ArrayList<DataModel> dataSet;

    public CustomAdapter(ArrayList<DataModel> dataSet) {

        this.dataSet = dataSet;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView textView_HeroName;
        TextView textView_HeroDescription;
        TextView textView_ID;
        ImageView imageViewIcon;

        public MyViewHolder (View itemView )
        {
            super(itemView);

            cardView = (CardView) itemView.findViewById(R.id.card_view);
            textView_HeroName = ( TextView) itemView.findViewById(R.id.textView_HeroName);
            textView_HeroDescription = ( TextView) itemView.findViewById(R.id.textView_HeroDescription);
            imageViewIcon = (ImageView) itemView.findViewById(R.id.imageView);
            textView_ID = (TextView) itemView.findViewById(R.id.textView_myID);

        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {

        View view = LayoutInflater.from(parent.getContext() ).inflate(R.layout.card_layout , parent ,false);

        MyViewHolder myViewHolder = new MyViewHolder(view);

        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder viewHolder,  int listPosition) {

        TextView textView_HeroName = viewHolder.textView_HeroName;
        TextView textView_HeroDescription = viewHolder.textView_HeroDescription;
        ImageView imageViewIcon = viewHolder.imageViewIcon;
        TextView textView_ID=viewHolder.textView_ID;
        CardView cardView = viewHolder.cardView;

        textView_HeroName.setText(dataSet.get(listPosition).getName());
        textView_HeroDescription.setText(dataSet.get(listPosition).getVersion());
        textView_ID.setText(String.valueOf(dataSet.get(listPosition).getId()));
        imageViewIcon.setImageResource(dataSet.get(listPosition).getImage());

        cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v ) {
                DataModel hero= new DataModel(viewHolder.textView_HeroName.getText().toString(),
                        viewHolder.textView_HeroDescription.getText().toString(),
                        Integer.parseInt((String) viewHolder. textView_ID.getText()),
                        viewHolder.imageViewIcon.getImageAlpha());
                FragmentFrontPageDirections.ShowHeroDeatails action= FragmentFrontPageDirections.showHeroDeatails(hero);
                Navigation.findNavController(cardView).navigate(action);

            }
        });

    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }


}
